package com.bezkoder.spring.jpa.onetoone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDataJpaOneToOneUnidirectionalApplicationTests {

	@Test
	void contextLoads() {
	}

}
